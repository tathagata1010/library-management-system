package com.dev.library.exception;

public class NotLibrarianException extends RuntimeException{
    public NotLibrarianException(String message) {
        super(message);
    }
}
