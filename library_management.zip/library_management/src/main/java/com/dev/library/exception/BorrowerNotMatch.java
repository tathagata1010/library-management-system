package com.dev.library.exception;

public class BorrowerNotMatch extends RuntimeException{
    public BorrowerNotMatch(String message) {
        super(message);
    }
}
